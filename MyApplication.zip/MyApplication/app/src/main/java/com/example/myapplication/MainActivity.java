package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Stack;

public class MainActivity extends AppCompatActivity {

    private TextView result;
    private TextView addedNums;
    private ArrayList<String> nums = new ArrayList<>();
    private char sign;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        result = findViewById(R.id.result);
        addedNums = findViewById(R.id.addedNums);
        result.setText("");
        addedNums.setText("");
    }

    public void numFunc(View view) {
        Button button = (Button) view;
        result.append(button.getText().toString());
    }

    public void addFunc(View view) {
        handleOperation('+');
    }

    public void funcMINU(View view) {
        handleOperation('-');
    }

    public void funcMUL(View view) {
        handleOperation('x');
    }

    public void funcDIV(View view) {
        handleOperation('/');
    }

    public void funcEqu(View view) {
        nums.add(result.getText().toString());
        if (nums.isEmpty()) return;

        // Convert the input into a postfix expression for correct precedence handling
        ArrayList<String> postfix = toPostfix(nums);

        // Evaluate the postfix expression
        float calcRes = evaluatePostfix(postfix);

        result.setText(Float.toString(calcRes));
        addedNums.setText("");
        nums.clear();
    }

    public void eraseAll(View view) {
        result.setText("");
        addedNums.setText("");
        nums.clear();
    }

    private void handleOperation(char operation) {
        if (!result.getText().toString().isEmpty()) {
            nums.add(result.getText().toString());
            if (addedNums.getText().toString().isEmpty()) {
                addedNums.setText(result.getText().toString() + " " + operation + " ");
            } else {
                addedNums.append(result.getText().toString() + " " + operation + " ");
            }
            result.setText("");
        }
        nums.add(String.valueOf(operation));
    }

    private ArrayList<String> toPostfix(ArrayList<String> infix) {
        ArrayList<String> postfix = new ArrayList<>();
        Stack<String> operators = new Stack<>();

        for (String token : infix) {
            if (isNumber(token)) {
                postfix.add(token);
            } else {
                while (!operators.isEmpty() && precedence(operators.peek()) >= precedence(token)) {
                    postfix.add(operators.pop());
                }
                operators.push(token);
            }
        }

        while (!operators.isEmpty()) {
            postfix.add(operators.pop());
        }

        return postfix;
    }

    private float evaluatePostfix(ArrayList<String> postfix) {
        Stack<Float> stack = new Stack<>();

        for (String token : postfix) {
            if (isNumber(token)) {
                stack.push(Float.parseFloat(token));
            } else {
                float b = stack.pop();
                float a = stack.pop();
                switch (token.charAt(0)) {
                    case '+':
                        stack.push(a + b);
                        break;
                    case '-':
                        stack.push(a - b);
                        break;
                    case 'x':
                        stack.push(a * b);
                        break;
                    case '/':
                        if (b == 0) {
                            throw new ArithmeticException("Division by zero");
                        }
                        stack.push(a / b);
                        break;
                }
            }
        }

        return stack.pop();
    }

    private boolean isNumber(String token) {
        try {
            Float.parseFloat(token);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private int precedence(String operator) {
        switch (operator) {
            case "x":
            case "/":
                return 2;
            case "+":
            case "-":
                return 1;
            default:
                return 0;
        }
    }
}