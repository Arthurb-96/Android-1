package com.example.carachters.classes;


import com.example.carachters.R;

public class myData {

    public static String[] nameArray = {"Arya Stark", "Cersei Lannister", "Jaime Lannister", "Joffrey Baratheon", "Jorah Mormont",
            "Oberyn Martel" ,"The hound","Tormund Giants Death","Tyrion Lannister","Tywin Lannister"};
    public static String[] House = {"Stark", "Lannister", "Lannister", "Baratheon", "(Ex)Mormont" ,
            "Martel" ,"The hound","The Free Folk","Lannister","Lannister"};
    public static Integer[] drawableArray = {R.drawable.arya, R.drawable.cerse, R.drawable.jaime,
             R.drawable.joffrey, R.drawable.jorah,R.drawable.oberyn,R.drawable.thehound,R.drawable.tormund,R.drawable.tyrion,
            R.drawable.tywin
            };

    public static Integer[] id_ = {0, 1, 2, 3, 4,5,6,7,8,9};


}
