package com.example.carachters;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.carachters.adapters.charachtersAdapter;
import com.example.carachters.classes.myData;
import com.example.carachters.models.Data;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements recyclerviewinterface {

    private charachtersAdapter charachters;
    private ArrayList<Data> arr;
    private RecyclerView rvCharachters;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        arr = new ArrayList<>();

        for (int i = 0; i < myData.nameArray.length; i++) {
            arr.add(new com.example.carachters.models.Data(
                    myData.nameArray[i],
                    myData.House[i],
                    myData.drawableArray[i],
                    myData.id_[i]

            ));
        }
        RecyclerView recyclerView = findViewById(R.id.rvChars);
        charachtersAdapter charachters = new charachtersAdapter(arr,this);
        recyclerView.setAdapter(charachters);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

    }

    @Override
    public void onItemClick(int position) {
        Toast.makeText(this, arr.get(position).getName() + " of house " + arr.get(position).getHouse(), Toast.LENGTH_SHORT).show();
    }
}