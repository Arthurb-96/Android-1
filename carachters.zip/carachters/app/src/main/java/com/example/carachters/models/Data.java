package com.example.carachters.models;
import android.os.Parcel;

public class Data {

    private String name;
    private String house;
    private int image;
    private int id;



    public Data(String name, String house,int image,int id) {
        this.name = name;
        this.house = house;
        this.image = image;
        this.id = id;

    }
    protected Data(Parcel in) {
        name = in.readString();
        house = in.readString();
        image = in.readInt();
        id = in.readInt();

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHouse() {
        return house;
    }

    public void setVersion(String version) {
        this.house = version;
    }

    public int getImage() {
        return image;
    }


    public int getId() {
        return id;
    }

}
