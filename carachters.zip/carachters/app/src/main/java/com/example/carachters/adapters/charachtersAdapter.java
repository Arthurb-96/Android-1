package com.example.carachters.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.carachters.R;
import com.example.carachters.models.Data;
import com.example.carachters.recyclerviewinterface;
import java.util.ArrayList;

public class charachtersAdapter extends RecyclerView.Adapter<charachtersAdapter.MyViewHolder> {
    private final recyclerviewinterface rvInterface;

    private ArrayList<Data> arr;

    public charachtersAdapter(ArrayList<Data> arr, recyclerviewinterface intrface) {
        rvInterface = intrface;
        this.arr = arr;
    }


    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvCharName, tvCharDesc;
        ImageView ivCharImage;
        CardView cvChar;

        public MyViewHolder(View itemView, recyclerviewinterface intrface) {
            super(itemView);


            cvChar = itemView.findViewById(R.id.cvChar);
            tvCharName = itemView.findViewById(R.id.tvCharName);
            tvCharDesc = itemView.findViewById(R.id.tvCharDesc);
            ivCharImage = itemView.findViewById(R.id.ivCharImage);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(intrface != null)
                    {
                         int position =getAdapterPosition();
                         if(position != RecyclerView.NO_POSITION)
                             intrface.onItemClick(position);
                    }
                }
            });
        }
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cartview, parent, false);
        return new MyViewHolder(view,rvInterface);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {


        Data data = arr.get(position);
        holder.tvCharName.setText(data.getName());
        holder.tvCharDesc.setText(data.getHouse());
        holder.ivCharImage.setImageResource(data.getImage());


    }

    @Override
    public int getItemCount() {
        return arr.size();
    }


}
