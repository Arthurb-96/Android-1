package com.example.carachters;

public interface recyclerviewinterface {
    public void onItemClick(int position);
}
